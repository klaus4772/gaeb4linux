package com.example.gaeb.core.model;
public class Project {}