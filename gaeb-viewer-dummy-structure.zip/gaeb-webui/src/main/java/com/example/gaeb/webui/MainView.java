package com.example.gaeb.webui;
public class MainView {}