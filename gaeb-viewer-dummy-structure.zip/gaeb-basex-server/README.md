# BaseX REST Endpoints

XQuery scripts live here.